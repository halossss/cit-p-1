/* 
    CIT 281 Project 1
    Name: Noah Berkstresser
*/
console.log(['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date().getDay()]);
