// Function to generate a random integer between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

function generateRandomString() {
    const alphabet = 'abcdefghijklmnopqrstuvwxyz'; // lowercase english alphabet
    const minLength = 5; // minimum length of random string
    const maxLength = 25; // maximum length of random string
    const length = getRandomInteger(minLength, maxLength + 1); // random length between minLength and maxLength (inclusive)

    let randomString = ''; // initialize an empty string to hold the random string

    // Loop to generate random characters and append them to the randomString
    for (let i = 0; i < length; i++) {
        const randomIndex = getRandomInteger(0, alphabet.length); // generate a random index within the length of the alphabet
        randomString += alphabet[randomIndex]; // append the random character at the randomIndex to the randomString
    }

    return randomString; // return the generated random string
}

// output a random string by calling the generateRandomString function and logging the result to the console
console.log(generateRandomString());